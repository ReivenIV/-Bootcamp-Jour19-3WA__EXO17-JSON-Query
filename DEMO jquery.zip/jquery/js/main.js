/*Jquery possède un seul sélecteur universel $("")*/

//.html équivaut à innerHTML
$("h3").html("Je suis un titre de niveau 3")//equivaut: document.querySelector("h3").innerHTML = "Je suis un titre de niveau 3"
//.text équivaut à innerText
$(".presentation").text("Coucou je suis un texte généré via jquery HAHAHAHA")

//.css équivaut à style

$("h1").css("color", "red") //équivaut: document.querySelector("h1").style.color = "red"



$(".blue").css("color", "blue")

// .on équivaut à addEventListener
//.show fait apparaitre et .hide fait disparaitre = visibility, fadeIn et fadeOut aussi
$("#show").on("click", function(e){
    e.preventDefault()
    //$(".blue").show()
    $(".blue").fadeIn("slow")
})

$("#hide").on("click", function(e){
    e.preventDefault()
    //$(".blue").hide()
    $(".blue").fadeOut("fast")
})



for(let i = 0; i < 5; i++){
    //création d'élément
    let li = $("<li>")// équivaut let li = document.createElement("li")
    li.html("lien numéro "+i)
    //data équivaut dataset
    li.data("index", i)
    //.append équivaut appendChild pour ajouter à la suite (l'inverse serait prepend)
    $("ul").append(li)
}


//.attr équivaut setAttribute si l'attribut src ici n'éxiste pas il le créera si il éxiste, il l'écrasera
$("img").attr("src", "http://pngimg.com/uploads/chuck_norris/chuck_norris_PNG10.png")

$("form button").on("click", function(e){
    e.preventDefault()
    //.val équivaut value
    let coucou = $("#coucou").val() //let coucou = document.getElementById("coucou").value
    console.log(coucou)
})

//.empty supprime le contenu de l'élément
//$("h4").empty()

//crée un événement de reset
//$("machin").trigger("reset")

//en jquery ils ont repris l'équivalent de classList

//.addClass ajoute une class, .removeClass supprime une class et .toggleClass équivaut à .classList.toggle(), .hasClass() pour savoir si la classe existe
$("ul").addClass("ul")

//pour les événement ils ont crée aussi les propriété .change(), .click(), dbl(click), .keydown(), .keyup(), .keypress()

/*équivaut à document.addEventListener("DOMContentLoaded", function(){
    
})*/
$(function(){
    console.log("salut")
})

//$(document).ready()